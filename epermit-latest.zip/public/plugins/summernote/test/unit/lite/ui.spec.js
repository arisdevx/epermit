/**
 * ui.spec.js
 * (c) 2015~ Summernote Team
 * summernote may be freely distributed under the MIT license./
 */
/* jshint unused: false */
define([
  'chai',
  'summernote/lite/ui'
], function (chai, ui) {
  'use strict';

  var expect = chai.expect;

  describe('lite:ui', function () {
  });
});
