<?php

namespace App\Http\Controllers;

use App\Models\Mode;
use App\Models\ModeRole;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;
use Flash;
use Validator;
use Log;

class ApplicantController extends Controller
{
	public function index()
	{
		return 'x';
	}
}