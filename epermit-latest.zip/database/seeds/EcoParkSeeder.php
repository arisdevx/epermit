<?php

use Illuminate\Database\Seeder;
use App\Models\EcoPark;

class EcoParkSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // EcoPark::truncate();
    }
}
