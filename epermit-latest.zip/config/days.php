<?php

return [
	1 => 'Hari Pertama',
	2 => 'Hari Kedua',
	3 => 'Hari Ketiga',
	4 => 'Hari Keempat',
	5 => 'Hari Kelima',
	6 => 'Hari Keenam',
	7 => 'Hari Ketujuh',
	8 => 'Hari Kedelapan',
	9 => 'Hari Kesembilan',
	10 => 'Hari Kesepuluh'
];